import { Component } from "@angular/core";

@Component({
    selector:'homeComp',
    templateUrl:'./home.component.html',
    styleUrls:['./home.component.css']
})
export class HomeComponent{

}