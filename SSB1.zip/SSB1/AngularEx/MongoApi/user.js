var bodyParser = require('body-parser')
var fs = require('fs')
var path = require('path')
var express = require('express');
var router  = express.Router();
var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var UserSchema = new Schema({
    uid: String,
    pwd: String,
    fname: String,
    lname: String,
    
});

mongoose.model('user', UserSchema);

var user = mongoose.model('user');

var allowCrossDomain = function (req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', '*');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
}

router.use(allowCrossDomain);
router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json())


router.get('/', (req, res) => {
    console.log('user module......')
    user.find({}, (err, docs) => {
        console.log(docs);
        res.send(docs)
    })
})

router.get('', (req, res, next) => {
    console.log('user module......')
    user.find({}, (err, docs) => {
        console.log(docs);
        res.send(docs)
    })
})


router.get('/:uid/:pwd', (req, res, next) => {
    var u = req.params.uid;
    var p = req.params.pwd
    console.log("User Id :" + p)
    user.find({$and:[{ uid: u},{pwd:p }]}, (err, docs) => {
        console.log(docs);
        res.send(docs)
    })
})

router.post('/', (req, res, next) => {
    console.log("Request Body : " + JSON.stringify(req.body));
    var usr = new user();
    usr.uid = req.body.uid
    usr.pwd = req.body.pwd
    usr.fname = req.body.fname
    usr.lname = req.body.lname
    usr.save(function (err, doc) {
        console.log('Saved....')
        res.json({ "message": "User Created ......." })
    });
})


module.exports= router