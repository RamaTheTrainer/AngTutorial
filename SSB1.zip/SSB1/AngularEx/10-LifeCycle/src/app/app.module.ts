import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router'

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AddplayerComponent } from './addplayer/addplayer.component';
import { DisplayplayersComponent } from './displayplayers/displayplayers.component';
import { PlayerdetailsComponent } from './playerdetails/playerdetails.component';
import { EditplayerComponent } from './editplayer/editplayer.component';

var rts: Routes = [
  { path: '', component: HomeComponent },
  { path: 'Home', component: HomeComponent },
  { path: 'About', component: AboutusComponent },
  { path: 'Contact', component: ContactusComponent },
  { path: 'AddPlayer', component: AddplayerComponent },
  { path: 'DisplayAll', component: DisplayplayersComponent },
  { path: 'PlayerDetails', component: PlayerdetailsComponent },
  { path: 'Login', component: LoginComponent }]
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutusComponent,
    ContactusComponent,
    LoginComponent,
    RegisterComponent,
    AddplayerComponent,
    DisplayplayersComponent,
    PlayerdetailsComponent,
    EditplayerComponent,
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(rts),
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
