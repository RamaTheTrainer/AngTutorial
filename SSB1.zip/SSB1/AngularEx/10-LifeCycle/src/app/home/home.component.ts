import { Component, OnInit, OnChanges, DoCheck } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnChanges, DoCheck {

  Name: string
  constructor() {
    this.Name = "Raja"
    alert("Constructor Invoked...")
  }
  btnClick()
  {
    this.Name ="harish"
  }
  ngDoCheck() {
    //alert("This is Do check ...")
    console.log('Docheck.....')
  }
  ngOnChanges() {
    alert('Change Occured...')
  }
  ngOnInit() {
    alert('Initailzing Data from DataSOurce : ngOnInit')
  }

}
