import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displayplayers',
  templateUrl: './displayplayers.component.html',
  styleUrls: ['./displayplayers.component.css']
})
export class DisplayplayersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
