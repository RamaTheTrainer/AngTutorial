import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editplayer',
  templateUrl: './editplayer.component.html',
  styleUrls: ['./editplayer.component.css']
})
export class EditplayerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
