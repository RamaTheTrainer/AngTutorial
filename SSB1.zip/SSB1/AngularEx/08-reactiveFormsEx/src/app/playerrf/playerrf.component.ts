import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms'
@Component({
  selector: 'app-playerrf',
  templateUrl: './playerrf.component.html',
  styleUrls: ['./playerrf.component.css']
})
export class PlayerrfComponent implements OnInit {

  frmGroup: FormGroup;
  frmBuilder: FormBuilder;
  vmsgpid:string=''
  vmsgpname: string=''
  constructor() {
    this.frmBuilder = new FormBuilder();
   }
   pidKeyup(){
     this.vmsgpid ='';
   }
   btnAddPlayerClick(){
     if(this.frmGroup.valid){
       alert("valid Form .. Submited to server ..")
     }
     else{
      if(this.frmGroup.controls["pid"].invalid){
        this.vmsgpid="pid Required and min 3 chars"
       }
     }
     
    // alert("FormGroup :" + this.frmGroup.valid)
    // alert("Valid: " + this.frmGroup.controls["pid"].valid + "Invalid : " + this.frmGroup.controls["pid"].invalid)
     //alert(JSON.stringify(this.frmGroup.value))
   }
  ngOnInit() {
    this.frmGroup = this.frmBuilder.group({
      pid:['',Validators.compose([Validators.required,Validators.minLength(3)])],
      pname:['', Validators.required],
      pimage:[''],
      pcountry:[''],
      page:['']
    });

  }

}
