import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayerrfComponent } from './playerrf.component';

describe('PlayerrfComponent', () => {
  let component: PlayerrfComponent;
  let fixture: ComponentFixture<PlayerrfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlayerrfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlayerrfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
