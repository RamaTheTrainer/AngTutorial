import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { PlayerComponent } from './player/player.component';

import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { DispalyPlayersComponent } from './dispaly-players/dispaly-players.component';
import { PlayerrfComponent } from './playerrf/playerrf.component'


@NgModule({
  declarations: [
    AppComponent,
    PlayerComponent,
    DispalyPlayersComponent,
    PlayerrfComponent,
  ],
  imports: [
    BrowserModule, FormsModule, ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
