import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  emp:any
  cr:string="";
  constructor() { 
    this.emp={"Name":"Rama","Designation":"Trainer","Salary":"3000"}
  }

  txtCourseKeyUp(course : any){
    this.cr = course.value
  }
  btnAdd(nm:any, c: any, sal: any){
      alert(nm.value + " || "+ c.value + " || " + sal.value);
    }


  ngOnInit() {
  }

}
