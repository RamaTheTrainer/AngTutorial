import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {

  favColor : string="";
  constructor() {

  }
  txtColorKeyUp(txtColor){
     this.favColor = txtColor.value
  
  }
  ngOnInit() {

  }
}