import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btsp-ex',
  templateUrl: './btsp-ex.component.html',
  styleUrls: ['./btsp-ex.component.css']
})
export class BtspExComponent implements OnInit {
  Employees: any[] = [
    { "Id": "1001", "Name": "Rama", "City": "Hyderabad","Salary":"4000","DOB": new Date() },
    { "Id": "1002", "Name": "Akash", "City": "Banglore","Salary":"2400","DOB": new Date() },
    { "Id": "1003", "Name": "Pawan", "City": "Hyderabad","Salary":"5000","DOB": new Date() },
    { "Id": "1004", "Name": "Mani", "City": "Delhi","Salary":"3500","DOB": new Date() },
    { "Id": "1005", "Name": "Ravi", "City": "Chennai","Salary":"6000","DOB": new Date() },
    { "Id": "1006", "Name": "Akhil", "City": "Delhi","Salary":"5200","DOB": new Date() }
  ]

  constructor() { }

  ngOnInit() {
  }

}
