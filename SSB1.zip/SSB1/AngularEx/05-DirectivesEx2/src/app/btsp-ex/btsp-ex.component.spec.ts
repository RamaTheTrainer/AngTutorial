import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtspExComponent } from './btsp-ex.component';

describe('BtspExComponent', () => {
  let component: BtspExComponent;
  let fixture: ComponentFixture<BtspExComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtspExComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtspExComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
