import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SampleclComponent } from './samplecl.component';

describe('SampleclComponent', () => {
  let component: SampleclComponent;
  let fixture: ComponentFixture<SampleclComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SampleclComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SampleclComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
