import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HomeComponent } from './Home/home.component'
import { AppComponent } from './app.component';
import { SampleComponent } from './sample/sample.component';
import { SampleclComponent } from './samplecl/samplecl.component';
import { BtspExComponent } from './btsp-ex/btsp-ex.component';



@NgModule({
  declarations: [
    AppComponent, HomeComponent, SampleComponent, SampleclComponent, BtspExComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
