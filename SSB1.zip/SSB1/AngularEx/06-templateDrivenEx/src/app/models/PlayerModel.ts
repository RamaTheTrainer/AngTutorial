export class Player {
    pid: number;
    pname: string;
    pimage: string;
    pcountry: string;
    page: number
}


