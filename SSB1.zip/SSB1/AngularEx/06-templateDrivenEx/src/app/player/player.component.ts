import { Component, OnInit } from '@angular/core';
import { Player } from '../models/PlayerModel'

@Component({
  selector: 'app-player',
  templateUrl: './player.component.html',
  styleUrls: ['./player.component.css']
})
export class PlayerComponent implements OnInit {

  pObj: Player
  constructor() {
    this.pObj = new Player();
  }
  frmSubmit(frm) {
    if (frm.valid) {
      alert('Submitted to Database...')
    }
    else{
      alert('Invlaid Data ')
    }

  }
  ngOnInit() {
  }

}
