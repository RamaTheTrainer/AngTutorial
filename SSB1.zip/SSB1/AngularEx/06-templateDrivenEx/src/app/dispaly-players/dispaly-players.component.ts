import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dispaly-players',
  templateUrl: './dispaly-players.component.html',
  styleUrls: ['./dispaly-players.component.css']
})
export class DispalyPlayersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
