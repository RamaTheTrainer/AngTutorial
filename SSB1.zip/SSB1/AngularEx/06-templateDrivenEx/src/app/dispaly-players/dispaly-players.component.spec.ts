import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DispalyPlayersComponent } from './dispaly-players.component';

describe('DispalyPlayersComponent', () => {
  let component: DispalyPlayersComponent;
  let fixture: ComponentFixture<DispalyPlayersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DispalyPlayersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DispalyPlayersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
