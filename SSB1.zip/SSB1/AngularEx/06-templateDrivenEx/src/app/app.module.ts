import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { PlayerComponent } from './player/player.component';

import {FormsModule} from '@angular/forms';
import { DispalyPlayersComponent } from './dispaly-players/dispaly-players.component'


@NgModule({
  declarations: [
    AppComponent,
    PlayerComponent,
    DispalyPlayersComponent,
  ],
  imports: [
    BrowserModule, FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
