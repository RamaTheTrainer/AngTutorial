import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {

  course : string ="Node"
 jsFrameworks : string[] =[];
 Employees:any[]=[];

  constructor() {
    this.Employees=[
                {"Id":"1001","Name":"Rama","City":"Hyderabad"},
                {"Id":"1002","Name":"Akash","City":"Banglore"},
                {"Id":"1003","Name":"Pawan","City":"Hyderabad"},
                {"Id":"1004","Name":"Akhil","City":"Delhi"}
              ]
   }
  btnAngular(){
    this.course= "Angular"
  }
  ngOnInit() {
    this.jsFrameworks =["Node JS","Express Js","Angular","React JS","Ext Js"]
  }

}
