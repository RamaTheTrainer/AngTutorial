import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private uServcObj: UserService, private rtr: Router) { }

  ngOnInit() {
  }
  btnLoginClick(u: any, p: any) {
    this.uServcObj.AuthenticateUser(u.value, p.value).subscribe((data) => {
      if (data.length > 0) {
        localStorage.setItem("uname", u.value)
        this.rtr.navigate(['Home'])
      }
      else
        alert("Invalid Login ...")
    })
  }
}
