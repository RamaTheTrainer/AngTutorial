import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PlayerService } from '../services/player.service';
import { Player } from '../models/PlayerModel';

@Component({
  selector: 'app-editplayer',
  templateUrl: './editplayer.component.html',
  styleUrls: ['./editplayer.component.css']
})
export class EditplayerComponent implements OnInit {
  ply: Player
  constructor(private acr: ActivatedRoute, private rtr :Router, private psObj: PlayerService) {
    this.ply = new Player()
  }
  btnEditPlayer() {
    this.psObj.UpdatePlayer(this.ply).subscribe((data) => {
      console.log(data);
    })
    this.rtr.navigate(['Home'])
  }
  ngOnInit() {
    let pid = this.acr.snapshot.params.id;
    this.psObj.GetPlayerById(pid).subscribe((data) => {
        this.ply = data[0];
    })
  }

}
