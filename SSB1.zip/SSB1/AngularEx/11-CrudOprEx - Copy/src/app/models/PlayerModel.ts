export class Player {
    pid: number;
    pname: string;
    pimage: any;
    pcountry: string;
    page: number
}


