export class User{
    uid: string;
    pwd:string;
    fname:string;
    lname: string;
}