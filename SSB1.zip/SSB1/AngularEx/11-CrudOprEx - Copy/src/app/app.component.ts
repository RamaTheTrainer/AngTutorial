import { Component, DoCheck } from '@angular/core';
import { Observable } from 'rxjs';
import { of } from 'rxjs'
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements DoCheck {
  loginStatus: string;
  constructor(private rtr:Router){
    
  }
  lnkLogoutClick() {
    localStorage.removeItem("uname");
    this.loginStatus=null
    console.log("Login Status :" + this.loginStatus)
    this.rtr.navigate(['Login'])
  }

  checkLocalStorage(): Observable<string> {
    return of(localStorage.getItem("uname"))
  }

  ngDoCheck() {
    this.checkLocalStorage().subscribe((data) => {
      this.loginStatus = data;
      console.log("Login Status :" + this.loginStatus)
    })
  }
}
