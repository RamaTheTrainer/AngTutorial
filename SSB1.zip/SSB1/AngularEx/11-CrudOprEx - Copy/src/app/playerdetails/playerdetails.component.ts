import { Component, OnInit } from '@angular/core';
import { PlayerService } from '../services/player.service';

@Component({
  selector: 'app-playerdetails',
  templateUrl: './playerdetails.component.html',
  styleUrls: ['./playerdetails.component.css'],
  
})
export class PlayerdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
