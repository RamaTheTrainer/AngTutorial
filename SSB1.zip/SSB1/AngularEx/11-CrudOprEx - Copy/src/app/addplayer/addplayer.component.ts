import { Component, OnInit } from '@angular/core';
import { Player } from '../models/PlayerModel'
import { PlayerService } from '../services/player.service';
import { Router } from '@angular/router'
@Component({
  selector: 'app-addplayer',
  templateUrl: './addplayer.component.html',
  styleUrls: ['./addplayer.component.css']
})
export class AddplayerComponent implements OnInit {

  player: Player;
  imgUrl: any
  constructor(private ps: PlayerService, private rt: Router) {
    this.player = new Player();

  }
  btnSavePlayer() {

     this.player.pimage =  this.player.pimage.replace("data:image/gif;base64,","");
     this.player.pimage =  this.player.pimage.replace("data:image/jpeg;base64,","");
     this.player.pimage =  this.player.pimage.replace("data:image/jpg;base64,","");
     this.player.pimage =  this.player.pimage.replace("data:image/png;base64,","");
     console.log(this.player.pimage);

    this.ps.AddPlayer(this.player).subscribe((data) => {
      console.log(data)
    })
    // //this.rt.navigate(['DisplayAll'])
     alert('Player Addedd Successfully....')
  }
  fileBrowse(event){
    if(event.target.files[0]){
        var rdr = new FileReader();
        rdr.readAsDataURL(event.target.files[0]);
        rdr.onload=(ev: any)=>{
          this.imgUrl = ev.target.result;
          this.player.pimage = rdr.result
          
        }
    }
  }
  ngOnInit() {
  }

}
