import { Component, OnInit } from '@angular/core';
import {PlayerService} from '../services/player.service'
import {Router} from '@angular/router'
@Component({
  selector: 'app-displayplayers',
  templateUrl: './displayplayers.component.html',
  styleUrls: ['./displayplayers.component.css']
})
export class DisplayplayersComponent implements OnInit {

  players:any[]=[]
  constructor(private psObj : PlayerService, private rtr : Router) {

   }

   btnDeleteClick(id){
    alert ("R u Sure  Deleted :"+ id );
    this.psObj.DeletePlayer(id).subscribe((data)=>{console.log(data)})
    
   }
   btnEditClick(id){
     //alert("player id:" + id)
      this.rtr.navigate(['Editplayer/'+id])
   }
  ngOnInit() {
    this.psObj.GetAllPlayers().subscribe((result)=>{
      console.log(result);
      this.players = result
    })
  }

}
