import { Component, OnInit } from '@angular/core';
import { User } from '../models/userModel';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  usr: User
  constructor(private uService : UserService ) {
    this.usr = new User();
   }
   btnSaveUser(){
    this.uService.AddUser(this.usr).subscribe((data)=>{
      alert(JSON.stringify(data))
    })
   }
  ngOnInit() {
  }

}
