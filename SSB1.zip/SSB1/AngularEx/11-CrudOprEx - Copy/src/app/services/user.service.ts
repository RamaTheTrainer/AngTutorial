import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../models/userModel';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url: string = 'http://localhost:3400/user'
  constructor(private htc: HttpClient) {

  }
  AddUser(usrInfo: User): Observable<any> {
    const reqOptns = {
      headers: new HttpHeaders({
        'content-type': 'application/json'
      })
    }
    alert(JSON.stringify(usrInfo))
    return this.htc.post(this.url, JSON.stringify(usrInfo), reqOptns)
  }
  AuthenticateUser(u: string, p: string):Observable<any> {
    return this.htc.get(this.url + '/' + u + '/' + p, { responseType: 'json' });
  }
}
