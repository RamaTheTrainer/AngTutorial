import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Player } from '../models/PlayerModel'

@Injectable({
  providedIn: 'root'
})
export class PlayerService {
  url: string = "http://localhost:3400/player"
  constructor(private htc: HttpClient) {

  }
  AddPlayer(pobj: Player): Observable<any> {
    const reqOptns = {
      headers: new HttpHeaders({
        'content-type': 'application/json'
      })
    }
    return this.htc.post(this.url, JSON.stringify(pobj), reqOptns)
  }
  GetAllPlayers(): Observable<any> {
    return this.htc.get(this.url, { responseType: 'json' })
  }
  GetPlayerById(id: number): Observable<any> {
    return this.htc.get(this.url + '/' + id, { responseType: 'json' })
  }
  UpdatePlayer(ply: Player): Observable<any>{
    const reqOptns = {
      headers: new HttpHeaders({
        'content-type': 'application/json'
      })
    }
    return this.htc.put(this.url,JSON.stringify(ply),reqOptns)
  }
  DeletePlayer(i: number): Observable<any> {
    return this.htc.delete(this.url + '/' + i, { responseType: 'json' })
  }
}
