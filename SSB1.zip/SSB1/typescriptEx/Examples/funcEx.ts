
// function DisplayDate(){
//     let dt = new Date();
//     let y = dt.getFullYear();
//     console.log("Current Year : " + y)
// }
//---------------------------------------------------
//DisplayDate();

// function Display(val: string){

// console.log(val.toUpperCase())

// }

// Display("siva soft")
//------------------------------------------------------


function Display(val : any) : string | number | any {
if(typeof val =="string")
return val.toUpperCase()
else if (typeof val == "number")
return val* val
else 
return undefined;
}

let res1 = Display("siva Soft");
console.log(res1);

let res2 = Display(45)
console.log(res2)

let res3 = Display({"id":10,"name":"rama"})
console.log(res3)













