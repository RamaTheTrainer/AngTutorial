var cDate = /** @class */ (function () {
    function cDate() {
    }
    return cDate;
}());
var rd = new Date(2017, 8, 23);
var nd = new Date();
var flag = true;
console.log(rd);
console.log(nd);
var ar = [];
while (flag) {
    if (rd >= nd) {
        break;
    }
    else {
        rd.setDate(rd.getDate() + 1);
        console.log(rd);
        var obj = void 0;
        obj = new cDate();
        obj.cd = rd;
        ar.push(obj);
    }
}
//console.log(ar)
