class cDate {
    cd:Date;
}
let  rd=new Date(2017,8,23);
let nd = new Date();
let flag:boolean = true;
console.log(rd)
console.log(nd)

let ar: any[] =[];

while(flag){
    if(rd>=nd){
        break;
    }
    else{
        rd.setDate(rd.getDate()+1);
        console.log(rd);
        let obj : cDate;
        obj = new cDate();
        obj.cd = rd;
        ar.push(obj);
    }
    
}
//console.log(ar)





