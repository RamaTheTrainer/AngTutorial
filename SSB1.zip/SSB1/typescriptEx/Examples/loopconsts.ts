
let n : number;

n=25;

for(let i=0;i<=10;i++){
    console.log(n +" * " + i + " = " + (n*i));
}



console.log('Series Done....')