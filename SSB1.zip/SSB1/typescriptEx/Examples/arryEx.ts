
let ar:number[]=[10,20,30,40,50]
                  
let Names:string[] =["Amar","Akash","Anil","Akash"]


let Emp : any;
Emp = {"eno":"1001","ename":"Rama","city":"Hyderabad"};

//console.log(Emp.eno + "   " + Emp.ename);


let Employees : any[]=[];
Employees= [
        {"eno":"1001","ename":"Rama","city":"Hyderabad"},
        {"eno":"1002","ename":"Rita","city":"Banglore"},
        {"eno":"1003","ename":"Gita","city":"Delhi"},
        {"eno":"1005","ename":"Sita","city":"Chennai"}
    ]

    console.log("EMPLOYEE LIST : ")
    
Employees.forEach(em => {
    console.log(em.eno + "   " + em.ename + "   " + em.city)
});



// Names.forEach(nm => {
//     console.log(nm.toUpperCase())
// });

// console.log("gener For Output : ")
// for(let i = 0;i<ar.length ;i++ ){
// console.log(ar[i])
// }

// console.log("From forEach Loop : ")
// ar.forEach(e => {
//     console.log("Square is :" + (e*e))
// });
