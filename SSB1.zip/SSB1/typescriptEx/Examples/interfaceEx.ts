interface ILoginCheck {
    ValidateLogin(): boolean;
}

class User implements ILoginCheck {
    uname: string;
    pwd: string;
    constructor() {
        this.uname = "aaa"
        this.pwd = "bbb";
    }

    ValidateLogin(): boolean {
        if (this.uname == "rama" && this.pwd == "hyd")
            return true;
        else
            return false
    }

}


let usrObj: User;
usrObj = new User();
usrObj.uname ="rama";
usrObj.pwd="hyd";

let valid: boolean = usrObj.ValidateLogin();

console.log("Is Valid?  :  " + valid)


