export class EmployeeModel{
    private  Id: number;
    Name: string;
    City: string;
    constructor(){
        this.Id=1000;
        this.Name="xxxx"
        this.City="cccc"
    }

    DisplayData(){
            console.log("Emp Id : " + this.Id)
            console.log("Emp Name : " + this.Name)
            console.log("Emp City : " + this.City)
        }

    AcceptData(){
           // this.Id= 1001;
            this.Name ="Rajesh"
            this.City="Hyderabad"
    }
}


class LoginModel{
    
}