
class Employee{
    private readonly Id: number;
    Name: string;
    City: string;
    constructor(){
        this.Id=1000;
        this.Name="xxxx"
        this.City="cccc"
    }

    DisplayData(){
            console.log("Emp Id : " + this.Id)
            console.log("Emp Name : " + this.Name)
            console.log("Emp City : " + this.City)
        }

    AcceptData(){
           // this.Id= 1001;
            this.Name ="Rajesh"
            this.City="Hyderabad"
    }
}


let empObj : Employee;
empObj = new Employee();

empObj.AcceptData();
empObj.DisplayData();


