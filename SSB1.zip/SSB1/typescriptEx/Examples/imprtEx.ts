import {EmployeeModel} from './EmployeeModel'
obj : EmployeeModel

let obj= new EmployeeModel();

obj.DisplayData();


