"use strict";
var m;
m = 56;
if (m >= 35)
    console.log("I am Pass...");
else
    console.log("I am Fail...");
console.log("TypeScript is Easy .....");
console.log("Thank U .");
